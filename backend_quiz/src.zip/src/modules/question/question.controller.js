const catchAsync = require("../../shared/catchAsync");
const sendResponse = require("../../shared/sendResponse");
const questionService = require("./question.service");

const addQuestion = catchAsync(async (req, res) => {
  const payload = { ...req.body };

  const question = await questionService.addQuestion(payload);

  if (question) {
    sendResponse(res, 200, true, "Question added successfully", question);
  } else {
    sendResponse(res, 400, false, "Failed to add question", {});
  }
});
const getAllQuestionByLevelId = catchAsync(async (req, res) => {
  const { levelId } = req.params;

  console.log(levelId);
  const level = await questionService.getAllQuestionByModelId(levelId, "level");

  if (level) {
    sendResponse(res, 200, true, "Question get successfully", level);
  } else {
    sendResponse(res, 400, false, "Failed to get question", {});
  }
});

const questionController = {
  addQuestion,
  getAllQuestionByLevelId,
};

module.exports = questionController;
