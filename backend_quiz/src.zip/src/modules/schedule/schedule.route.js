const express = require("express");
const categoryController = require("./schedule.controller.js");
const USER_ROLE = require("../../helpers/userRole.js");
const auth = require("../../middlewares/auth.js");
const fileUpload = require("../../middlewares/fileUpload.js");

const upload = fileUpload("./src/uploads/category/");
const categoryRouter = express.Router();

categoryRouter
  .post(
    "",
    // auth.verifyRole(USER_ROLE.ADMIN, USER_ROLE.SUPER_ADMIN),
    upload.fields([{ name: "image", maxCount: 1 }]),
    categoryController.addCategory
  )
  .get("", categoryController.getAllCategory);

module.exports = categoryRouter;
